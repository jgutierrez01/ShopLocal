USE [SAM]
GO

INSERT INTO [dbo].[Pagina]
           ([PermisoID]
           ,[Url])
     VALUES
           (117,
		   '/WorkStatus/RepEmbarque.aspx')
GO


