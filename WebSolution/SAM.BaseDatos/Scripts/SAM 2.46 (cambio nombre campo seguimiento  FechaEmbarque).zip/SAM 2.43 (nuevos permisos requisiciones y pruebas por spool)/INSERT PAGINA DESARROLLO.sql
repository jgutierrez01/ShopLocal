GO

INSERT INTO [dbo].[Pagina]
           ([PermisoID]
           ,[Url])
     VALUES
           (1812
		   , '/WorkStatus/LstRequisicionesSpoolPruebas.aspx')

INSERT INTO [dbo].[Pagina]
           ([PermisoID]
           ,[Url])
     VALUES
           (1813
		   , '/WorkStatus/LstSpoolPnd.aspx')
GO