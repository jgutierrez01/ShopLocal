
GO
--INSERT PERMISO

INSERT INTO [dbo].[Permiso]
           ([ModuloID]
           ,[Nombre]
           ,[NombreIngles])
     VALUES
           (1
		   , 'Requisiciones por Spool'
		   , 'Test Spool Requisitions' )

INSERT INTO [dbo].[Permiso]
           ([ModuloID]
           ,[Nombre]
           ,[NombreIngles])
     VALUES
           (1
		   , 'Pruebas por Spool'
		   , 'Test per Spool' )

GO


