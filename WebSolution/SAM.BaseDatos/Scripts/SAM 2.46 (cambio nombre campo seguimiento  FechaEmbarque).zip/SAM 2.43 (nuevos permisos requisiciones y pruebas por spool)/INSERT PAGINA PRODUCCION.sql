GO

INSERT INTO [dbo].[Pagina]
           ([PermisoID]
           ,[Url])
     VALUES
           (143
		   , '/WorkStatus/LstRequisicionesSpoolPruebas.aspx')

INSERT INTO [dbo].[Pagina]
           ([PermisoID]
           ,[Url])
     VALUES
           (144
		   , '/WorkStatus/LstSpoolPnd.aspx')
GO


